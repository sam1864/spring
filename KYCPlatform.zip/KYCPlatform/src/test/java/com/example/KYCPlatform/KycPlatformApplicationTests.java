package com.example.KYCPlatform;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class KycPlatformApplicationTests {

	@Test
	void contextLoads() {
	}

}
